# Banking Customer Onboarding Analysis

An independent BA and data analytics portfolio case study using **600 synthetic applications**. SQL analysis, a formula-driven Excel dashboard, process maps, requirements and acceptance criteria are included.

**Status:** Packaged analytical case study. Process changes are proposals, not implemented outcomes.
**Reporting snapshot:** 30 September 2026. Applications started July-August 2026.
**Tools:** SQL (SQLite-validated, MySQL-compatible core syntax), Excel, Python standard library for reproducible data generation and validation.

![Excel dashboard](dashboard/dashboard_preview.png)

## Business question
Where do applications stop progressing, how do channel outcomes differ, and which changes should a fictional bank investigate first?

## Findings from the synthetic dataset
| Measure | Result |
|---|---:|
| Applications | 600 |
| Completed | 365 (60.83%) |
| Abandoned | 140 (23.33%) |
| Pending | 69 (11.50%) |
| Rejected | 26 (4.33%) |
| Document-stage abandonments | 56 (40.00% of all abandonments) |

Mobile completion is 53.63% (155/289), website 63.55% (136/214), and branch 76.29% (74/97). Completed mobile applications average 8.72 calendar days versus 7.13 for website and 6.69 for branch. These differences were intentionally simulated and are not evidence about actual banking customers or channel causality.

## Recommended next steps
1. Prototype document upload validation and save/resume. Documents account for 56 of 140 abandoned applications; 31 list upload difficulty.
2. Investigate verification queues and status visibility. Verification accounts for 44 of 140 abandonments; 24 list verification wait.
3. Validate the hypotheses using actual event data, user interviews and a controlled pilot before setting improvement targets.

## Repository contents
- `data/applications.csv`: one row per application.
- `data/data_dictionary.md`: fields, missing values and metric definitions.
- `sql/01_setup.sql`: table creation and all 600 records.
- `sql/02_analysis.sql`: seven analysis and quality queries.
- `sql/codechef_complete.sql`: setup and queries in one pasteable script.
- `results/`: reproducible query outputs and validation report.
- `dashboard/onboarding_dashboard.xlsx`: editable formulas, two charts and source records.
- `docs/business_analysis.md`: scope, stakeholders, process maps, requirements and UAT cases.
- `docs/findings.md`: interpretation and limitations.
- `docs/interview_guide.md`: explanation of the project and interview questions.
- `docs/github_upload.md`: browser upload and run instructions.
- `docs/resume_bullets.md`: suggested evidence-based resume wording.
- `scripts/generate_data.py` and `scripts/validate_project.py`: standard-library reproduction tools.

## Run in an online SQL editor
Paste the complete contents of `sql/codechef_complete.sql` into an empty SQL session and run. No database credentials are needed. Keep the setup and analysis together if the editor starts a fresh database on each run. Use a new session for reruns if your editor preserves tables; do not run setup against unrelated existing data.

## Run locally with SQLite
With Python 3 installed, from the repository root:
```bash
python scripts/validate_project.py
```
This creates an in-memory database, executes the SQL, compares result CSVs, checks dates and statuses, and prints a summary. No third-party packages are required.

To regenerate data: `python scripts/generate_data.py`. Seed 42 and fixed generation rules reproduce the delivered CSV. The SQL inserts and workbook are the delivered snapshot; changing generator rules requires rebuilding both, not just regenerating the CSV.

For MySQL: create/select a dedicated database, execute `01_setup.sql`, then `02_analysis.sql`. MySQL execution has not been verified in this environment. Date-difference functions were deliberately avoided in the shared queries; `completion_days` is derived and checked by the generation/validation scripts.

## Excel usage
Open the workbook in Excel. Dashboard formulas read rows 5-604 of Data. Filter source data using the table filters for inspection; these filters do not change dashboard metrics. Edit a record within that range to recalculate the dashboard and charts. Extend formula/chart source ranges if adding records. The workbook is a fixed 600-record case study, not an automated ingestion pipeline. Completion days in the workbook are calculated from dates.

## Method and attribution
The dataset uses a deterministic random seed and deliberately different channel completion probabilities and document delays. It is designed to practise analysis, not estimate a population. Abandonment reasons and pending statuses are generated labels, not measured customer behaviour. Pending applications remain separate from abandonment. Funnel gaps include all non-progressed outcomes, not just abandonment. Durations describe completed applications only.

This package was prepared with AI assistance for data generation, SQL, workbook construction and documentation. Anyone presenting it should run the scripts, inspect the formulas and explain the assumptions. It contains no actual customer data or client work, and claims no deployed business impact.
