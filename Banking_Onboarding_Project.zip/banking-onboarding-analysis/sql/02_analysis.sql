-- Queries work in SQLite and MySQL 8.0. Dates are ISO YYYY-MM-DD.

-- 01_overall
SELECT COUNT(*) AS applications,
 SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END) AS completed,
 SUM(CASE WHEN status='Abandoned' THEN 1 ELSE 0 END) AS abandoned,
 SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END) AS pending,
 SUM(CASE WHEN status='Rejected' THEN 1 ELSE 0 END) AS rejected,
 ROUND(100.0*SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END)/COUNT(*),2) AS completion_rate_pct
FROM applications;

-- 02_channel
SELECT channel, COUNT(*) AS applications,
 SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END) AS completed,
 SUM(CASE WHEN status='Abandoned' THEN 1 ELSE 0 END) AS abandoned,
 SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END) AS pending,
 SUM(CASE WHEN status='Rejected' THEN 1 ELSE 0 END) AS rejected,
 ROUND(100.0*SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END)/COUNT(*),2) AS completion_rate_pct,
 ROUND(AVG(CASE WHEN status='Completed' THEN completion_days END),2) AS avg_completed_days
FROM applications GROUP BY channel ORDER BY channel;

-- 03_abandonment_stage
SELECT exit_stage, COUNT(*) AS abandoned,
 ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM applications WHERE status='Abandoned'),2) AS share_of_abandoned_pct
FROM applications WHERE status='Abandoned'
GROUP BY exit_stage ORDER BY abandoned DESC, exit_stage;

-- 04_reasons
SELECT exit_stage, reason, COUNT(*) AS abandoned
FROM applications WHERE status='Abandoned'
GROUP BY exit_stage, reason ORDER BY abandoned DESC, exit_stage, reason;

-- 05_funnel
SELECT '1. Started' AS milestone, COUNT(*) AS reached FROM applications
UNION ALL SELECT '2. Details submitted', COUNT(details_date) FROM applications
UNION ALL SELECT '3. Documents submitted', COUNT(documents_date) FROM applications
UNION ALL SELECT '4. Verification completed', COUNT(verification_date) FROM applications
UNION ALL SELECT '5. Account opened', COUNT(completed_date) FROM applications
ORDER BY milestone;

-- 06_month
SELECT SUBSTR(started_date,1,7) AS start_month, COUNT(*) AS applications,
 ROUND(100.0*SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END)/COUNT(*),2) AS completion_rate_pct
FROM applications GROUP BY SUBSTR(started_date,1,7) ORDER BY start_month;

-- 07_data_quality
SELECT
 COUNT(*)-COUNT(DISTINCT application_id) AS duplicate_ids,
 SUM(CASE WHEN status NOT IN ('Completed','Abandoned','Pending','Rejected') THEN 1 ELSE 0 END) AS invalid_statuses,
 SUM(CASE WHEN (status='Completed' AND completed_date IS NULL)
 OR (status<>'Completed' AND completed_date IS NOT NULL) THEN 1 ELSE 0 END) AS completion_mismatches,
 SUM(CASE WHEN details_date<started_date OR documents_date<details_date
 OR verification_date<documents_date OR completed_date<verification_date THEN 1 ELSE 0 END) AS date_order_errors
FROM applications;
