# Interview preparation

## Thirty-second explanation
This is an AI-assisted independent portfolio case study of a fictional bank's onboarding process. It uses 600 synthetic applications. I used SQL outputs to compare channels and progression, and the package includes an Excel dashboard and proposed BA requirements. Document submission represents 40% of simulated abandonments. I would validate upload and verification hypotheses with real events and customer research before recommending rollout.

Use the explanation only after reviewing/running the work; describe your personal contribution accurately.

## What to understand before listing this project
1. Run `codechef_complete.sql` and find the 600 total and 365 completed records.
2. Explain `SUM(CASE WHEN ... THEN 1 ELSE 0 END)` and the completion-rate denominator.
3. Open Excel, inspect a COUNTIFS formula and a duration formula.
4. Explain why 56/140 is share of abandonments, not a stage-specific risk.
5. Read BR-01 and describe its three upload boundary tests.
6. Explain that requirements are proposed and application UAT has not been executed.
7. Explain synthetic data, seed 42, simulated channel differences and AI assistance.

## Questions and answers
**Why SQL and Excel?** SQL provides explicit repeatable aggregations; Excel provides a familiar review surface with editable formulas and charts.

**What does one row represent?** One application. No real person or customer is represented.

**Why 100.0 in SQL?** It keeps the percentage calculation in decimal arithmetic rather than integer division.

**Why separate pending and abandoned?** A pending case may still finish. Missing milestone dates alone cannot establish abandonment.

**Is mobile worse in the real world?** This dataset cannot establish that. Channel probabilities and delays were deliberately simulated. Customer mix and process differences could confound actual comparisons.

**Why not claim reduced drop-offs?** No workflow was deployed. The project produces recommendations and testable requirements, not realised benefits.

**How do you validate?** Keys are unique, status counts reconcile, timestamps are ordered and within snapshot, completed durations match dates, funnel counts decrease, and rerun query outputs match delivered CSVs.

**What would you add next?** Actual upload event logs, device categories, time-to-outcome with a fixed follow-up window, stakeholder discovery, and a controlled pilot.

## Small personal extension
Add a query for abandonment rate by channel, export its result and explain it in your own words. This gives you a concrete contribution beyond the delivered baseline.
