# Findings and recommendations

All figures describe synthetic data. Snapshot: 2026-09-30, applications started July-August 2026.

## 1. Overall completion
365 of 600 applications completed (60.83%); 140 abandoned, 69 pending and 26 rejected. Pending is an active status, not abandonment.

## 2. Channel comparison
| Channel | Total | Completed | Completion | Mean completed days |
|---|---:|---:|---:|---:|
| Branch | 97 | 74 | 76.29% | 6.69 |
| Mobile | 289 | 155 | 53.63% | 8.72 |
| Website | 214 | 136 | 63.55% | 7.13 |

Mobile completion is 9.92 percentage points below website (using unrounded rates). This is an association created by generation rules, not proof that the channel causes abandonment. Branch is an assisted comparison group, not an equivalent control.

## 3. Document stage is the largest abandonment category
56/140 abandonments (40%) occur while awaiting document submission. Of those, 31 are labelled upload difficulty and 25 document unavailable. Prioritise validating upload/recovery hypotheses. Do not describe 40% as a document-stage abandonment rate; its denominator is all abandoned applications.

## 4. Verification is the next category
44/140 abandonments (31.43%) occur awaiting verification. Twenty-four list verification wait. Investigate queue updates and visibility. The data has no verification service-level target, so no SLA breach conclusion is supported.

## 5. Funnel gaps are not all abandonment
600 started, 569 submitted details, 479 submitted documents, 421 completed the verification step, and 365 opened accounts. The 90-record gap between details and documents includes both pending and abandoned cases. The last gap also includes rejected applications.

## Limits and validation
SQL ran in SQLite and exported seven result sets. Validation checks unique keys, stage continuity, date order, snapshot cutoffs, allowed statuses, durations, reproducible generation and result-file agreement. MySQL syntax uses portable constructs but was not executed on a MySQL server. The Excel workbook is separately formula-driven and was checked in the authoring engine; native desktop Excel was not available for execution testing. Review dashboard recalculation when first opening it.

No actual bank, customer sample, user interview or implemented process is represented. Long-lived pending cases are deliberately possible at snapshot. Durations for completed applications exclude censored pending cases and do not measure the experience of every applicant.
