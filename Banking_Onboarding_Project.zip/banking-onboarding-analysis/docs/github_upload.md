# Upload and run

## Upload from your computer
1. Download and extract the project ZIP.
2. Open your existing repository: https://github.com/shivaaani15/-banking-onboarding-analysis
3. Choose Add file > Upload files on the repository Code page.
4. Drag the CONTENTS of the extracted `banking-onboarding-analysis` folder into the upload area. Include README.md and the data, sql, docs, results, dashboard and scripts folders. Upload the extracted contents, not just the ZIP.
5. If GitHub indicates README.md already exists, review the replacement so the new project introduction becomes the repository homepage.
6. Commit with a message such as `Add onboarding analysis case study and dashboard`.
7. Verify the homepage renders the README and you can open the SQL, CSV, BA document and workbook. GitHub may offer the workbook as a download rather than preview.

If the browser cannot upload folders, create each folder by entering its path in Add file > Create new file, or use GitHub Desktop. Keep the folder layout intact so relative links and reproduction scripts resolve.

## Run without installing anything
Open `sql/codechef_complete.sql` on GitHub, copy the raw file contents, paste the whole script into CodeChef's SQL editor and run. Do not paste into the input box. Use the code editor. It includes CREATE TABLE, inserts and analysis queries. An online editor may limit output or runtime; use setup plus one analysis query if needed. The script was validated locally with SQLite, not executed in CodeChef during package creation.

## Open the dashboard
Download `dashboard/onboarding_dashboard.xlsx` and open it in Excel. The Dashboard tab shows overall metrics, channel comparison, a milestone chart and an abandonment-stage chart. Data holds all source records and a duration formula. Filtering the Data table does not filter dashboard formulas.

## Attach to your resume
After uploading and reviewing the project, use the link above with the wording in `docs/resume_bullets.md`. Read `docs/interview_guide.md` before an interview.
