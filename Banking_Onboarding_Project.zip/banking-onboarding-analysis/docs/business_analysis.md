# Business analysis case study

## Problem and scope
A fictional retail bank wants to understand digital account-opening drop-offs. Analyse application progression and propose testable workflow requirements. In scope: channel comparisons, onboarding milestones, completion time, document upload and verification communication. Out of scope: credit underwriting, regulatory interpretation, production integration, identity verification algorithms, actual customer research and implemented benefits.

## Assumed stakeholders
| Stakeholder | Need | Proposed responsibility |
|---|---|---|
| Onboarding product owner | Prioritised backlog and clear measures | Approve scope and business rules |
| Operations lead | Queue visibility and workable exceptions | Validate process and escalation |
| Customer support | Clear status and recovery instructions | Validate customer messages |
| Engineering / QA | Testable requirements and edge cases | Estimate, implement and test |
| Compliance / security | Appropriate access and document handling | Review production requirements |

These are hypothetical stakeholders. No interviews were performed.

## Current process (assumed)
```mermaid
flowchart TD
 A[Start application] --> B[Submit details]
 B --> C[Upload documents]
 C --> D{Documents usable?}
 D -->|No| E[Request resubmission]
 E --> C
 D -->|Yes| F[Process verification]
 F --> G{Eligible and verified?}
 G -->|Yes| H[Open account]
 G -->|No| I[Reject with permitted explanation]
```
Customers may abandon or remain pending at each uncompleted stage. Dataset milestones show submission, not every upload attempt; the rework loop is a process hypothesis requiring validation.

## Proposed process
```mermaid
flowchart TD
 A[Start or resume application] --> B[Save details and checklist]
 B --> C[Upload with immediate feedback]
 C --> D{File meets upload rules?}
 D -->|No| E[Explain error and retain progress]
 E --> C
 D -->|Yes| F[Verification queue with status updates]
 F --> G{Decision}
 G -->|Approved| H[Open account and notify]
 G -->|More information| I[Request specific correction]
 I --> C
 G -->|Rejected| J[Notify using approved message]
```

## Prioritised requirements and acceptance criteria
Priorities are illustrative, subject to product-owner validation. Upload formats and limits below are demo assumptions, not bank policies.

| ID | Priority | Requirement | Acceptance criteria | Evidence |
|---|---|---|---|---|
| BR-01 | Must | Validate upload format and size before submission | Given JPG, PNG or PDF up to 5 MB, allow upload; reject unsupported types or files over 5 MB with a specific message; keep other saved data | 31 upload-difficulty abandonments |
| BR-02 | Must | Save and resume an application | Given saved progress and an authenticated returning applicant, restore saved fields and uploaded-document status without creating a duplicate application | Document-stage friction; validate with users |
| BR-03 | Must | Show verification status | Given an application under review, display current state and last update; never display approval before an approved decision | 24 verification-wait abandonments |
| BR-04 | Should | Escalate stale verification cases | Given an open case with no update for more than 2 calendar days, flag it once to operations; exclude closed cases | Proposed threshold for pilot, not an observed SLA breach |
| BR-05 | Must | Publish consistent reporting definitions | A fixed snapshot produces separate completed, abandoned, pending and rejected counts that reconcile to total applications | Prevents pending/abandoned conflation |
| BR-06 | Should | Record recovery events | For each upload failure and retry, capture application key, event type and timestamp without document content in analytics logs | Current dataset cannot measure retries |

## User stories
- As an applicant, I want an actionable upload error so I can correct the file and continue. Links to BR-01.
- As an applicant, I want to resume saved work so I do not re-enter information. Links to BR-02.
- As an operations analyst, I want stale cases flagged so I can prioritise follow-up. Links to BR-04.

## UAT scenarios (designed, not executed against an app)
| Test | Requirement | Scenario | Expected outcome |
|---|---|---|---|
| UAT-01 | BR-01 | Upload valid 5 MB PDF | Accepted at boundary |
| UAT-02 | BR-01 | Upload 5.1 MB PDF | Rejected with size explanation; saved details retained |
| UAT-03 | BR-01 | Upload unsupported EXE file | Rejected with permitted formats |
| UAT-04 | BR-02 | Resume authenticated saved application | Same application key and saved state restored |
| UAT-05 | BR-03 | Open an under-review application | Current review state shown; no false approval |
| UAT-06 | BR-04 | Open case older than 2 days vs exactly 2 days | Older case flagged, boundary case unflagged; rerun creates no duplicate alert |
| UAT-07 | BR-05 | Reconcile snapshot outcomes | 365+140+69+26 = 600; Pending excluded from abandonment |

## Pilot measurement plan
Instrument upload starts, failures, retries, verification updates and account opening. Establish actual baselines before rollout. Randomise an eligible digital cohort to current vs improved upload flow if feasible; keep eligibility controls consistent. Primary measure: account-open rate within a predefined follow-up window. Secondary: document-stage abandonment and upload retry success. Guardrails: rejection errors, support contacts, complaints and privacy incidents. Determine sample size and duration from real baseline rates and minimum detectable effect. No uplift target or realised ROI is claimed here.

## Open questions for discovery
How is abandonment actually recorded? What are upload failure rates by device? Are channel customers comparable? What document rules and retention rules apply? Does verification time include weekends? Who owns exception queues? Validate accessibility, permissions, retention and notifications before production.
