# Resume entry

**Banking Customer Onboarding Analysis | Independent Portfolio Project**
SQL, Excel, Business Process Analysis | 2026

- Analysed 600 synthetic banking applications using SQL to compare channel completion, onboarding milestones and abandonment reasons; identified document submission as 40% of simulated abandonments.
- Developed a formula-driven Excel dashboard and documented current/proposed workflows, six business requirements and seven UAT scenarios for onboarding improvements.

GitHub: https://github.com/shivaaani15/-banking-onboarding-analysis

Use this entry after uploading and reviewing the deliverables. Keep it under Projects, separate from Quantiphi employment. Describe it as AI-assisted if asked about development. Do not claim production deployment, real customers, measured uplift, executed application UAT or independent authorship of all code. Python is a supporting generation tool here; do not list Python proficiency solely because the script is included.
