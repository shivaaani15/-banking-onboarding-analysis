# Data dictionary and measurement rules

**Grain:** one application, unique `application_id`. Multiple applications by the same person are not modelled. Snapshot 2026-09-30; starts 2026-07-01 through 2026-08-31.

| Field | Type | Definition |
|---|---|---|
| application_id | Integer | Unique fictional application key |
| channel | Text | Mobile, Website or Branch |
| status | Text | Completed, Abandoned, Pending or Rejected at snapshot |
| started_date | ISO date | Application started |
| details_date | Nullable ISO date | Personal details submitted |
| documents_date | Nullable ISO date | Required documents submitted |
| verification_date | Nullable ISO date | Verification step processed; does not imply approval |
| completed_date | Nullable ISO date | Account opened; populated only for Completed |
| exit_stage | Nullable text | Next uncompleted stage for Pending/Abandoned; Account opening for Rejected; blank for Completed |
| reason | Nullable text | Simulated abandonment/rejection reason, In progress for Pending; blank for Completed |
| completion_days | Nullable integer | completed_date minus started_date in calendar days; Completed only |

CSV empty cells map to SQL NULL. Missing stage dates mean not reached, not zero-day completion. Dates have day precision; same-day transitions are permitted. A rejected application has a verification_date because the check was processed, even when it failed.

## Metric definitions
- Completion rate: Completed / all applications in the cohort at the fixed snapshot. Pending and rejected remain in the denominator.
- Abandonment rate: Abandoned / all applications. Status is explicitly simulated, never inferred from a missing date or inactivity.
- Share of abandonment: Abandoned at a stage / all Abandoned. This is not the probability of abandonment among stage entrants.
- Funnel reached: count of non-null milestone dates, with Started equal to all applications. Adjacent gaps contain Pending, Rejected and Abandoned outcomes.
- Mean completion time: average calendar-day duration among Completed only. Pending time is right-censored and excluded, so this cannot estimate all-applicant waiting time.
- Month: month of started_date, not completion month.

## Generation assumptions
Seed 42; 600 applications. Channel sampling weights: Mobile 50%, Website 35%, Branch 15%. Status weights (Completed, Abandoned, Pending, Rejected): Mobile [53,29,13,5]%, Website [65,19,11,5]%, Branch [78,8,8,6]%. Actual sample shares differ through random sampling. Mobile document submission delays are deliberately longer. Full logic is in `scripts/generate_data.py`. No missing/error records were injected for cleaning demonstrations; quality checks validate an already structured dataset.
