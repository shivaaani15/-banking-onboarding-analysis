"""Validate the delivered SQL, data and results. Requires only Python 3."""
import csv, json, sqlite3
from pathlib import Path
from datetime import date
from generate_data import generate, HEADERS

root=Path(__file__).resolve().parents[1]
with (root/'data/applications.csv').open(newline='') as f:
    reader=csv.DictReader(f); records=list(reader)
assert len(records)==600
assert len({r['application_id'] for r in records})==600
assert [[str(v) for v in row] for row in generate()]==[[r[h] for h in HEADERS] for r in records]
allowed={'Completed','Abandoned','Pending','Rejected'}
for r in records:
    assert r['status'] in allowed
    assert r['channel'] in {'Mobile','Website','Branch'}
    raw=[r[k] for k in ['started_date','details_date','documents_date','verification_date','completed_date']]
    seen_blank=False
    for d in raw:
        if not d: seen_blank=True
        else: assert not seen_blank, 'Stage cannot skip a previous milestone'
    dates=[date.fromisoformat(d) for d in raw if d]
    assert dates==sorted(dates) and max(dates)<=date(2026,9,30)
    assert date(2026,7,1)<=dates[0]<=date(2026,8,31)
    assert bool(r['completed_date'])==(r['status']=='Completed')
    if r['status']=='Completed':
        assert int(r['completion_days'])==(dates[-1]-dates[0]).days
        assert not r['exit_stage'] and not r['reason']
    else: assert not r['completion_days'] and r['exit_stage'] and r['reason']
db=sqlite3.connect(':memory:')
db.executescript((root/'sql/01_setup.sql').read_text())
expected=json.loads((root/'results/verified_results.json').read_text())
text=(root/'sql/02_analysis.sql').read_text()
checks=0
for statement in text.split(';'):
    if 'SELECT' not in statement: continue
    name=next(n for n in expected if '-- '+n in statement)
    cur=db.execute(statement)
    actual=[dict(zip([d[0] for d in cur.description],r)) for r in cur.fetchall()]
    assert actual==expected[name], name
    with (root/f'results/{name}.csv').open(newline='') as f:
        csv_rows=list(csv.DictReader(f))
    assert csv_rows==[{k:str(v) for k,v in r.items()} for r in actual], name
    checks+=1
assert checks==7
assert db.execute('SELECT COUNT(*) FROM applications').fetchone()[0]==len(records)
stored=db.execute('SELECT * FROM applications ORDER BY application_id').fetchall()
assert [[str(v) if v is not None else '' for v in row] for row in stored]==[[r[h] for h in HEADERS] for r in records]
funnel=[r['reached'] for r in expected['05_funnel']]
assert funnel==sorted(funnel,reverse=True)
report={'status':'passed','records':600,'query_result_sets_verified':checks,'checks':['generator reproduces CSV','unique keys','valid categories','stage continuity','ordered dates and snapshot cutoff','completion status and duration','SQL inserts equal CSV','seven result CSVs equal rerun SQL','monotonic funnel']}
(root/'results/validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
