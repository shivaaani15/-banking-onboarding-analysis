"""Generate fictional application records. Python standard library only."""
import csv, random
from pathlib import Path
from datetime import date, timedelta

def generate():
    rng=random.Random(42)
    rows=[]
    for i in range(1,601):
        channel=rng.choices(['Mobile','Website','Branch'],[.5,.35,.15])[0]
        weights={'Mobile':[.53,.29,.13,.05], 'Website':[.65,.19,.11,.05], 'Branch':[.78,.08,.08,.06]}[channel]
        status=rng.choices(['Completed','Abandoned','Pending','Rejected'],weights)[0]
        stage=4 if status=='Completed' else (3 if status=='Rejected' else rng.choices([0,1,2,3],[.12,.43,.30,.15])[0])
        start=date(2026,7,1)+timedelta(days=rng.randrange(62))
        timestamps=[start]
        delays=[rng.randint(0,2),rng.randint(1,5) if channel=='Mobile' else rng.randint(0,3),rng.randint(1,6),rng.randint(0,2)]
        for k in range(4):
            timestamps.append(timestamps[-1]+timedelta(days=delays[k]) if k<stage else None)
        exit_stage='' if status=='Completed' else ['Details','Documents','Verification','Account opening'][stage]
        reason=''
        if status=='Abandoned':
            reason=rng.choice({'Details':['Form too long','Customer withdrew'], 'Documents':['Upload difficulty','Document unavailable'], 'Verification':['Verification wait','Customer withdrew'], 'Account opening':['Customer withdrew','Product mismatch']}[exit_stage])
        elif status=='Rejected': reason=rng.choice(['Identity mismatch','Eligibility not met'])
        elif status=='Pending': reason='In progress'
        row=[i,channel,status]+[d.isoformat() if d else '' for d in timestamps]+[exit_stage,reason,(timestamps[4]-start).days if status=='Completed' else '']
        rows.append(row)
    return rows

HEADERS=['application_id','channel','status','started_date','details_date','documents_date','verification_date','completed_date','exit_stage','reason','completion_days']
if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    with (root/'data/applications.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(HEADERS);w.writerows(generate())
    print('Generated 600 synthetic applications using seed 42.')
